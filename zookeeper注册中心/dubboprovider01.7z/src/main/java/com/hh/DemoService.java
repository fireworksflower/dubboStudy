package com.hh;

/**
 * Created by IntelliJ IDEA.
 * User: NinetyOne
 * Date: 2019/1/22
 * Time: 13:50
 * To change this template use File | Setting | File Template.
 **/
public interface DemoService {
    public String say(String name);
}
